﻿namespace StateCapsSearchPart1
{
    partial class AddStateCapForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtBoxState = new System.Windows.Forms.TextBox();
            this.TxtBoxCapital = new System.Windows.Forms.TextBox();
            this.LstBoxStateCaps = new System.Windows.Forms.ListBox();
            this.BtnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(75, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "State";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Capital";
            // 
            // TxtBoxState
            // 
            this.TxtBoxState.Location = new System.Drawing.Point(137, 58);
            this.TxtBoxState.Name = "TxtBoxState";
            this.TxtBoxState.Size = new System.Drawing.Size(197, 20);
            this.TxtBoxState.TabIndex = 2;
            // 
            // TxtBoxCapital
            // 
            this.TxtBoxCapital.Location = new System.Drawing.Point(137, 98);
            this.TxtBoxCapital.Name = "TxtBoxCapital";
            this.TxtBoxCapital.Size = new System.Drawing.Size(197, 20);
            this.TxtBoxCapital.TabIndex = 2;
            // 
            // LstBoxStateCaps
            // 
            this.LstBoxStateCaps.FormattingEnabled = true;
            this.LstBoxStateCaps.Location = new System.Drawing.Point(424, 29);
            this.LstBoxStateCaps.Name = "LstBoxStateCaps";
            this.LstBoxStateCaps.Size = new System.Drawing.Size(218, 199);
            this.LstBoxStateCaps.TabIndex = 3;
            this.LstBoxStateCaps.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(137, 151);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(197, 23);
            this.BtnSave.TabIndex = 4;
            this.BtnSave.Text = "&Save";
            this.BtnSave.UseVisualStyleBackColor = true;
            // 
            // AddStateCapForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 288);
            this.Controls.Add(this.BtnSave);
            this.Controls.Add(this.LstBoxStateCaps);
            this.Controls.Add(this.TxtBoxCapital);
            this.Controls.Add(this.TxtBoxState);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddStateCapForm";
            this.Text = "Add State & Capital Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtBoxState;
        private System.Windows.Forms.TextBox TxtBoxCapital;
        private System.Windows.Forms.ListBox LstBoxStateCaps;
        private System.Windows.Forms.Button BtnSave;
    }
}

